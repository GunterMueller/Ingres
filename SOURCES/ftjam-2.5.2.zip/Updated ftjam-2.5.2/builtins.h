/*
 * Copyright 1993-2002 Christopher Seiwald and Perforce Software, Inc.
 *
 * This file is part of Jam - see jam.c for Copyright information.
 */

/*
 * builtins.h - compile parsed jam statements
 *
 * 01/10/01 (seiwald) - split from compile.h
 */

void load_builtins();

