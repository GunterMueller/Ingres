/*
**	driverefstub.h
**
**      history:
**      31-Jul-1998 (musro02)
**          Remove trailing ";" to prevent "empty declaration"
**	11-jun-2003 (abbjo03)
**	    Add return statements to prevent warnings on VMS.
*/

#ifndef	EFA01
int	efa01() { return 0; }
#endif

#ifndef	EFA02
int	efa02() { return 0; }
#endif

#ifndef	EFA03
int	efa03() { return 0; }
#endif

#ifndef	EFA04
int	efa04() { return 0; }
#endif

#ifndef	EFA05
int	efa05() { return 0; }
#endif

#ifndef	EFA06
int	efa06() { return 0; }
#endif

#ifndef	EFA07
int	efa07() { return 0; }
#endif

#ifndef	EFA08
int	efa08() { return 0; }
#endif

#ifndef	EFA09
int	efa09() { return 0; }
#endif

#ifndef	EFA10
int	efa10() { return 0; }
#endif

#ifndef	EFA11
int	efa11() { return 0; }
#endif

#ifndef	EFA12
int	efa12() { return 0; }
#endif

#ifndef	EFA13
int	efa13() { return 0; }
#endif

#ifndef	EFA14
int	efa14() { return 0; }
#endif

#ifndef	EFA15
int	efa15() { return 0; }
#endif

#ifndef	EFA16
int	efa16() { return 0; }
#endif

#ifndef	EFA17
int	efa17() { return 0; }
#endif

#ifndef	EFA18
int	efa18() { return 0; }
#endif

#ifndef	EFA19
int	efa19() { return 0; }
#endif

#ifndef	EFA20
int	efa20() { return 0; }
#endif

#ifndef	EFA21
int	efa21() { return 0; }
#endif

#ifndef	EFA22
int	efa22() { return 0; }
#endif

#ifndef	EFA23
int	efa23() { return 0; }
#endif

#ifndef	EFA24
int	efa24() { return 0; }
#endif

#ifndef	EFA25
int	efa25() { return 0; }
#endif

#ifndef EFA26
int     efa26() { return 0; }
#endif

#ifndef EFA27
int     efa27() { return 0; }
#endif

#ifndef EFA29
int     efa29() { return 0; }
#endif
