/*
**	driveregstub.h
**      history:
**      31-Jul-1998 (musro02)
**          Remove trailing ";" to prevent "empty declaration"
**	11-jun-2003 (abbjo03)
**	    Add return statements to prevent warnings on VMS.
*/

#ifndef EGA06
int     ega06() { return 0; }
#endif

#ifndef EGA07
int     ega07() { return 0; }
#endif

#ifndef EGA08
int     ega08() { return 0; }
#endif




