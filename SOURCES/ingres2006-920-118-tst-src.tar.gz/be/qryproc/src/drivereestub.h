/*
**	drivereestub.h
**
**      history:
**      31-Jul-1998 (musro02)
**          Remove trailing ";" to prevent "empty declaration"
**	11-jun-2003 (abbjo03)
**	    Add return statements to prevent warnings on VMS.
*/

#ifndef	EEA01
int	eea01() { return 0; }
#endif

#ifndef	EEA02
int	eea02() { return 0; }
#endif

#ifndef	EEA03
int	eea03() { return 0; }
#endif

#ifndef	EEA04
int	eea04() { return 0; }
#endif

#ifndef	EEA05
int	eea05() { return 0; }
#endif

#ifndef	EEA06
int	eea06() { return 0; }
#endif

#ifndef	EEA07
int	eea07() { return 0; }
#endif

#ifndef	EEA08
int	eea08() { return 0; }
#endif

#ifndef EEA09
int     eea09() { return 0; }
#endif

#ifndef EEA10
int     eea10() { return 0; }
#endif

#ifndef EEA11
int     eea11() { return 0; }
#endif

#ifndef EEA12
int     eea12() { return 0; }
#endif

#ifndef EEA13
int     eea13() { return 0; }
#endif

#ifndef EEA14
int     eea14() { return 0; }
#endif

#ifndef EEA15
int     eea15() { return 0; }
#endif

#ifndef EEA16
int     eea16() { return 0; }
#endif

