/*
**	driverelstub.h
**
**      history:
**      31-Jul-1998 (musro02)
**          Remove trailing ";" to prevent "empty declaration"
**	11-jun-2003 (abbjo03)
**	    Add return statements to prevent warnings on VMS.
*/

#ifndef	ELA01
int	ela01() { return 0; }
#endif

#ifndef	ELA02
int	ela02() { return 0; }
#endif

#ifndef	ELA03
int	ela03() { return 0; }
#endif

#ifndef	ELA04
int	ela04() { return 0; }
#endif

#ifndef	ELA05
int	ela05() { return 0; }
#endif

#ifndef	ELA06
int	ela06() { return 0; }
#endif

#ifndef	ELA07
int	ela07() { return 0; }
#endif

#ifndef	ELA08
int	ela08() { return 0; }
#endif

#ifndef	ELA09
int	ela09() { return 0; }
#endif

#ifndef	ELA10
int	ela10() { return 0; }
#endif

#ifndef	ELA11
int	ela11() { return 0; }
#endif

#ifndef	ELA12
int	ela12() { return 0; }
#endif

#ifndef	ELA13
int	ela13() { return 0; }
#endif

#ifndef	ELA14
int	ela14() { return 0; }
#endif

#ifndef	ELA15
int	ela15() { return 0; }
#endif
