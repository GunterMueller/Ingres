/*
**	cdstub.h
*/

#ifndef	CDA24
int	cda24() {};
#endif
