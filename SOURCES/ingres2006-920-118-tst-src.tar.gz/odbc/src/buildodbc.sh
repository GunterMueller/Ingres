sepcc -I$II_SYSTEM/ingres/files odbctest
seplnk odbctest $SEPPARAM_ODBCLIB
