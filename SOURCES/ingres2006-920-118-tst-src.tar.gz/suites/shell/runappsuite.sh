#!/bin/sh
#
#  Copyright (c) 2005-2006 Ingres Corporation. All Rights Reserved.
#
#
#  Appsuite Stress Test Execution Script
#
#  09-Feb-2006 (sarjo01) Created. 
#

#
# Function: Build executable
# 
makeit() {
    cp $ING_TST/stress/appsuite/$appname.sc . >> $outputdir/appsuite.out
    chmod +w ./$appname.sc >> $outputdir/appsuite.out
    esqlc -multi $appname >> $outputdir/appsuite.out 
    sepcc $appname >> $outputdir/appsuite.out
    seplnk $appname >> $outputdir/appsuite.out
    if [ ! -f ./$appname.exe ]
    then
        echo "ERROR: Failed to build $appname.exe"
        exit 1 
    fi
}
#
# Function: Display command syntax
#
errorHelp() {
    echo ""
    echo "Usage:"
    echo ""
    echo "  sh \$TST_SHELL/runappsuite.sh all"
    echo "     or"
    echo "  sh \$TST_SHELL/runappsuite.sh test [ test test ... ]"
    echo "     where test is any of"
    echo "           ddlv1 insdel ordent qp1 qp3 selv1 updv1"
    echo ""
    exit 1
}

appsuitelist="ddlv1 insdel ordent qp1 qp3 selv1 updv1"
dolist=
appname=
appsuitedb=

if [ "$1" = "" ]
then
    errorHelp
fi
if [ "$1" = "all" ]
then
    dolist=$appsuitelist
else
    dolist=$*
fi

umask 2 

#
# Set up output directory
#
if [ "$TST_ROOT_OUTPUT" != "" ]
then
    outputdir=$TST_ROOT_OUTPUT/appsuite
else 
    echo "ERROR: TST_ROOT_OUTPUT not set"
    exit 1 
fi
export outputdir 
if [ ! -d $outputdir ]
then
    echo "Creating output directory $outputdir"
    mkdir $outputdir
fi
if [ ! -d $outputdir ]
then
    echo "ERROR: Could not create output directory $outputdir"
    exit 1
fi

echo ""
echo "Output directory: $outputdir"
cd $outputdir
echo `date`, "Begin Appsuite tests" > $outputdir/appsuite.out

if [ "$SEPPARAMDB" != "" ]
then
    appsuitedb=$SEPPARAMDB 
else 
    appsuitedb="appsuitedb"
fi
export appsuitedb 
destroydb $appsuitedb >> $outputdir/appsuite.out
createdb $appsuitedb >> $outputdir/appsuite.out

for appname in $dolist
do
    case $appname in
                  ddlv1|insdel|ordent|qp1|qp3|selv1|updv1)
                      ;;
                  *)
                      errorHelp
                      ;;
    esac
    export appname 
    echo ""
    echo `date`," Building  $appname..."
    makeit
    echo `date`," Executing $appname..."
    echo `date`," Executing $appname..." >> $outputdir/appsuite.out
    qawtl APPSUITE: Begin $appname... 
    case $appname in
         ddlv1)
             ./ddlv1.exe $appsuitedb init > ./$appname.out
             ./ddlv1.exe $appsuitedb run -t16 -v0 -i5000 -s250 >> ./$appname.out
             ;;
         insdel)
             ./insdel.exe $appsuitedb init -p32 > ./$appname.out
             ./insdel.exe $appsuitedb run -t24 -v0 -i50000 -d10 -b5 -h50000 >> ./$appname.out
             ;;
         ordent)
             ./ordent.exe $appsuitedb init -d > ./$appname.out
             ./ordent.exe $appsuitedb run -t24 -v0 -i50000 -w1 -lr >> ./$appname.out
             ;;
         qp1)
             cp $ING_TST/stress/appsuite/qp1*.data .
             ./qp1.exe $appsuitedb init > ./$appname.out
             chmod +w ./qp1*.data
             rm ./qp1*.data
             optimizedb -zk $appsuitedb
             ./qp1.exe $appsuitedb run -t10 -v0 -i1000 -p >> ./$appname.out
             ;;
         qp3)
             cp $ING_TST/stress/appsuite/qp3*.data .
             ./qp3.exe $appsuitedb init > ./$appname.out
             chmod +w ./qp3*.data
             rm ./qp3*.data
             optimizedb -zk $appsuitedb
             ./qp3.exe $appsuitedb run -t4 -v0 -i50 -p >> ./$appname.out
             ;;
         selv1)
             ./selv1.exe $appsuitedb init -r50000 -p32 -o500 > ./$appname.out
             ./selv1.exe $appsuitedb run -t24 -v0 -i100000 -z >> ./$appname.out
             ;;
         updv1)
             ./updv1.exe $appsuitedb init -p10 -c > ./$appname.out
             ./updv1.exe $appsuitedb run -t24 -v0 -i20000 -b5 >> ./$appname.out
             ;;
         *)
              echo "$appname...?"
             ;;
    esac
    ./$appname.exe $appsuitedb cleanup >> ./$appname.out

done
echo ""
echo `date`," Cleaning up..."
rm -f ./*.sc ./*.c *.exe ./*.o
echo `date`," Done"
echo `date`," Done" >> $outputdir/appsuite.out
