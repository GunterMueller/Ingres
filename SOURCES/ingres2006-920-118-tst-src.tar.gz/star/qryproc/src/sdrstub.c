/*
**	sdrstub.c
*/

#ifndef	SZA01
void	sza01() 
{
}
#endif

#ifndef	SZA02
void	sza02() 
{
}
#endif

#ifndef	SZA03
void	sza03() 
{
}
#endif

#ifndef	SZA04
void	sza04() 
{
}
#endif

#ifndef	SZA05
void	sza05() 
{
}
#endif

#ifndef	SZA06
void	sza06() 
{
}
#endif

#ifndef	SZA07
void	sza07() 
{
}
#endif

#ifndef	SZA08
void	sza08() 
{
}
#endif

#ifndef	SZA09
void	sza09() 
{
}
#endif

#ifndef	SZA10
void	sza10() 
{
}
#endif

#ifndef	SZA11
void	sza11() 
{
}
#endif

#ifndef	SZA12
void	sza12() 
{
}
#endif

#ifndef	SZA13
void	sza13() 
{
}
#endif

#ifndef	SZA14
void	sza14() 
{
}
#endif

#ifndef	SZA15
void	sza15() 
{
}
#endif

#ifndef SZA16
void     sza16() 
{
}
#endif

